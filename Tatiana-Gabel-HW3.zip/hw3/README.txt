TCP server class
   is responsible for creating a socket which will accept 2 clients
   then it transmitted data to the client
   and displays information about the clients

TCP client class
    connects to server, and receives data
    it will display this information
    currently, only supports 2 clients